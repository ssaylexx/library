from src.models import Book

book1 = Book("Название1", "Автор1", 1991, "978-5-17-080077-7")
print(book1)
